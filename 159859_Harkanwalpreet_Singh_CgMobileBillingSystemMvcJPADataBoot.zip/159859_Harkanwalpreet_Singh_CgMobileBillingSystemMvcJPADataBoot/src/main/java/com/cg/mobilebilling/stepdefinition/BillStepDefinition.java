package com.cg.mobilebilling.stepdefinition;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class BillStepDefinition {
	@Given("^User is on generate monthly bill page$")
	public void user_is_on_generate_monthly_bill_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters <customerID>, <mobileNo> and <billMonth>$")
	public void user_enters_customerID_mobileNo_and_billMonth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicks on generate monthly bill submit button$")
	public void clicks_on_generate_monthly_bill_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Check whether given details are valid$")
	public void check_whether_given_details_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Calculate monthly <bill> on the basis of consumption and <plan>$")
	public void calculate_monthly_bill_on_the_basis_of_consumption_and_plan() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display monthly <bill> on monthly bill display page$")
	public void display_monthly_bill_on_monthly_bill_display_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on monthly bill page$")
	public void user_is_on_monthly_bill_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicks on monthly bill display submit button$")
	public void clicks_on_monthly_bill_display_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Display monthly <bill> if available for that month display monthly bill display page$")
	public void display_monthly_bill_if_available_for_that_month_display_monthly_bill_display_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Provide option for downloading Bill in pdf format$")
	public void provide_option_for_downloading_Bill_in_pdf_format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
